UltraMix — Master Bundle
========================

📂 Structure:
- footage/   -> Place your recordings here.
- exports/   -> Export final videos here.
- timelines/ -> CSV, XML, EDL timeline guides.
- graphics/  -> Lower Thirds + Title Cards (Dark/Light 3D versions).
- UltraMix.mogrt -> Motion Graphics Template for Premiere Pro.

🎬 How to use MOGRT:
1. Open Premiere Pro > Essential Graphics panel.
2. Click "Install Motion Graphics Template" and select UltraMix.mogrt.
3. Drag template to timeline, edit text (any language), change colors.

📖 Documentation:
See UltraMix-Guide.pdf for a full step-by-step illustrated guide.